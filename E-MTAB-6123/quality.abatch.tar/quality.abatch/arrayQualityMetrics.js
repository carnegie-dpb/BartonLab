// (C) Wolfgang Huber 2010-2011

// Script parameters - these are set up by R in the function 'writeReport' when copying the 
//   template for this script from arrayQualityMetrics/inst/scripts into the report.

var highlightInitial = [ true, false, true, true, false, true, true, true, true, false, true, false, true, true, true, true, true, true, false, true, true, false, false, false, false, false, false, true, false, false ];
var arrayMetadata    = [ [ "1", "H1003422_JGL1157-10_70920.CEL", "1", "08/19/08 09:43:08" ], [ "2", "H1003423_JGL1157-11_70904.CEL", "2", "08/19/08 10:11:47" ], [ "3", "H1003424_JGL1157-12_70916.CEL", "3", "08/19/08 09:18:11" ], [ "4", "H1003425_JGL1157-13_70927.CEL", "4", "08/19/08 09:55:16" ], [ "5", "H1003426_JGL1157-14_70924.CEL", "5", "08/19/08 10:00:59" ], [ "6", "H1003427_JGL1157-15_70909.CEL", "6", "08/19/08 09:21:10" ], [ "7", "H1003431_JGL1157-19_70932.CEL", "7", "08/19/08 09:44:49" ], [ "8", "H1003432_JGL1157-20_70935.CEL", "8", "08/19/08 09:50:44" ], [ "9", "H1003433_JGL1157-21_70925.CEL", "9", "08/19/08 09:56:41" ], [ "10", "H1003434_JGL1157-22_70903.CEL", "10", "08/19/08 10:17:38" ], [ "11", "H1003435_JGL1157-23_70919.CEL", "11", "08/19/08 10:02:17" ], [ "12", "H1003436_JGL1157-24_70906.CEL", "12", "08/19/08 09:37:19" ], [ "13", "H1003440_JGL1157-28_70905.CEL", "13", "08/19/08 11:24:35" ], [ "14", "H1003441_JGL1157-29_70910.CEL", "14", "08/19/08 11:18:47" ], [ "15", "H1003442_JGL1157-30_70908.CEL", "15", "08/19/08 11:12:49" ], [ "16", "H1003443_JGL1157-31_59970.CEL", "16", "08/20/08 17:58:09" ], [ "17", "H1003444_JGL1157-32_59991.CEL", "17", "08/20/08 18:04:12" ], [ "18", "H1003445_JGL1157-33_59992.CEL", "18", "08/20/08 18:10:10" ], [ "19", "H1003446_JGL1157-34_59994.CEL", "19", "08/20/08 18:54:07" ], [ "20", "H1003447_JGL1157-35_59995.CEL", "20", "08/20/08 18:28:10" ], [ "21", "H1003448_JGL1157-36_60044.CEL", "21", "08/20/08 18:34:09" ], [ "22", "H1003449_JGL1157-37_60049.CEL", "22", "08/20/08 19:00:00" ], [ "23", "H1003450_JGL1157-38_60052.CEL", "23", "08/20/08 19:05:53" ], [ "24", "H1003451_JGL1157-39_60063.CEL", "24", "08/20/08 18:48:11" ], [ "25", "H1003452_JGL1157-40_60067.CEL", "25", "08/20/08 17:52:12" ], [ "26", "H1003453_JGL1157-41_60886.CEL", "26", "08/20/08 18:16:10" ], [ "27", "H1003454_JGL1157-42_60887.CEL", "27", "08/20/08 18:22:12" ], [ "28", "H1003455_JGL1157-43_60889.CEL", "28", "08/20/08 18:58:05" ], [ "29", "H1003456_JGL1157-44_60890.CEL", "29", "08/20/08 19:03:58" ], [ "30", "H1003457_JGL1157-45_60892.CEL", "30", "08/20/08 18:52:02" ] ];
var svgObjectNames   = [ "pca", "dens", "dig" ];

var cssText = ["stroke-width:1; stroke-opacity:0.4",
               "stroke-width:3; stroke-opacity:1" ];

// Global variables - these are set up below by 'reportinit'
var tables;             // array of all the associated ('tooltips') tables on the page
var checkboxes;         // the checkboxes
var ssrules;


function reportinit() 
{
 
    var a, i, status;

    /*--------find checkboxes and set them to start values------*/
    checkboxes = document.getElementsByName("ReportObjectCheckBoxes");
    if(checkboxes.length != highlightInitial.length)
	throw new Error("checkboxes.length=" + checkboxes.length + "  !=  "
                        + " highlightInitial.length="+ highlightInitial.length);
    
    /*--------find associated tables and cache their locations------*/
    tables = new Array(svgObjectNames.length);
    for(i=0; i<tables.length; i++) 
    {
        tables[i] = safeGetElementById("Tab:"+svgObjectNames[i]);
    }

    /*------- style sheet rules ---------*/
    var ss = document.styleSheets[0];
    ssrules = ss.cssRules ? ss.cssRules : ss.rules; 

    /*------- checkboxes[a] is (expected to be) of class HTMLInputElement ---*/
    for(a=0; a<checkboxes.length; a++)
    {
	checkboxes[a].checked = highlightInitial[a];
        status = checkboxes[a].checked; 
        setReportObj(a+1, status, false);
    }

}


function safeGetElementById(id)
{
    res = document.getElementById(id);
    if(res == null)
        throw new Error("Id '"+ id + "' not found.");
    return(res)
}

/*------------------------------------------------------------
   Highlighting of Report Objects 
 ---------------------------------------------------------------*/
function setReportObj(reportObjId, status, doTable)
{
    var i, j, plotObjIds, selector;

    if(doTable) {
	for(i=0; i<svgObjectNames.length; i++) {
	    showTipTable(i, reportObjId);
	} 
    }

    /* This works in Chrome 10, ssrules will be null; we use getElementsByClassName and loop over them */
    if(ssrules == null) {
	elements = document.getElementsByClassName("aqm" + reportObjId); 
	for(i=0; i<elements.length; i++) {
	    elements[i].style.cssText = cssText[0+status];
	}
    } else {
    /* This works in Firefox 4 */
    for(i=0; i<ssrules.length; i++) {
        if (ssrules[i].selectorText == (".aqm" + reportObjId)) {
		ssrules[i].style.cssText = cssText[0+status];
		break;
	    }
	}
    }

}

/*------------------------------------------------------------
   Display of the Metadata Table
  ------------------------------------------------------------*/
function showTipTable(tableIndex, reportObjId)
{
    var rows = tables[tableIndex].rows;
    var a = reportObjId - 1;

    if(rows.length != arrayMetadata[a].length)
	throw new Error("rows.length=" + rows.length+"  !=  arrayMetadata[array].length=" + arrayMetadata[a].length);

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = arrayMetadata[a][i];
}

function hideTipTable(tableIndex)
{
    var rows = tables[tableIndex].rows;

    for(i=0; i<rows.length; i++) 
 	rows[i].cells[1].innerHTML = "";
}


/*------------------------------------------------------------
  From module 'name' (e.g. 'density'), find numeric index in the 
  'svgObjectNames' array.
  ------------------------------------------------------------*/
function getIndexFromName(name) 
{
    var i;
    for(i=0; i<svgObjectNames.length; i++)
        if(svgObjectNames[i] == name)
	    return i;

    throw new Error("Did not find '" + name + "'.");
}


/*------------------------------------------------------------
  SVG plot object callbacks
  ------------------------------------------------------------*/
function plotObjRespond(what, reportObjId, name)
{

    var a, i, status;

    switch(what) {
    case "show":
	i = getIndexFromName(name);
	showTipTable(i, reportObjId);
	break;
    case "hide":
	i = getIndexFromName(name);
	hideTipTable(i);
	break;
    case "click":
        a = reportObjId - 1;
	status = !checkboxes[a].checked;
	checkboxes[a].checked = status;
	setReportObj(reportObjId, status, true);
	break;
    default:
	throw new Error("Invalid 'what': "+what)
    }
}

/*------------------------------------------------------------
  checkboxes 'onchange' event
------------------------------------------------------------*/
function checkboxEvent(reportObjId)
{
    var a = reportObjId - 1;
    var status = checkboxes[a].checked;
    setReportObj(reportObjId, status, true);
}


/*------------------------------------------------------------
  toggle visibility
------------------------------------------------------------*/
function toggle(id){
  var head = safeGetElementById(id + "-h");
  var body = safeGetElementById(id + "-b");
  var hdtxt = head.innerHTML;
  var dsp;
  switch(body.style.display){
    case 'none':
      dsp = 'block';
      hdtxt = '-' + hdtxt.substr(1);
      break;
    case 'block':
      dsp = 'none';
      hdtxt = '+' + hdtxt.substr(1);
      break;
  }  
  body.style.display = dsp;
  head.innerHTML = hdtxt;
}
